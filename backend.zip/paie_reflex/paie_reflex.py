"""Main app module - required by Reflex framework."""
# This file is required by Reflex to locate the app
# It imports the app from __init__.py
from paie_reflex import app

__all__ = ["app"]
